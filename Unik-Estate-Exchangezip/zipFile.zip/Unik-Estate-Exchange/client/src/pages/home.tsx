import { Layout } from "@/components/layout";
import { HeroSlider } from "@/components/hero-slider";
import { ListingCard } from "@/components/listing-card";
import { listings } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Building2, GraduationCap, Home as HomeIcon, Search, ShieldCheck } from "lucide-react";

export default function Home() {
  const featuredListings = listings.filter(l => l.isFeatured);

  return (
    <Layout>
      <HeroSlider />
      
      {/* Featured Categories */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-heading font-bold mb-4">Browse by Category</h2>
            <p className="text-muted-foreground">Find exactly what you're looking for, from premium properties to student essentials.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Link href="/listings?category=real-estate">
              <a className="group relative overflow-hidden rounded-2xl aspect-[4/3] bg-white shadow-sm hover:shadow-xl transition-all">
                <div className="absolute inset-0 bg-primary/5 group-hover:bg-primary/10 transition-colors" />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10">
                  <div className="bg-white p-4 rounded-full shadow-sm mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Building2 className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-heading font-bold text-xl mb-1">Real Estate</h3>
                  <p className="text-sm text-muted-foreground">Lands, Housing, Shops</p>
                </div>
              </a>
            </Link>

            <Link href="/listings?category=student-items">
              <a className="group relative overflow-hidden rounded-2xl aspect-[4/3] bg-white shadow-sm hover:shadow-xl transition-all">
                <div className="absolute inset-0 bg-primary/5 group-hover:bg-primary/10 transition-colors" />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10">
                  <div className="bg-white p-4 rounded-full shadow-sm mb-4 group-hover:scale-110 transition-transform duration-300">
                    <GraduationCap className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-heading font-bold text-xl mb-1">Student Marketplace</h3>
                  <p className="text-sm text-muted-foreground">Buy & Sell Used Items</p>
                </div>
              </a>
            </Link>

            <Link href="/listings?category=hostels">
              <a className="group relative overflow-hidden rounded-2xl aspect-[4/3] bg-white shadow-sm hover:shadow-xl transition-all">
                <div className="absolute inset-0 bg-primary/5 group-hover:bg-primary/10 transition-colors" />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10">
                  <div className="bg-white p-4 rounded-full shadow-sm mb-4 group-hover:scale-110 transition-transform duration-300">
                    <HomeIcon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-heading font-bold text-xl mb-1">Hostels</h3>
                  <p className="text-sm text-muted-foreground">Student Accommodation</p>
                </div>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Latest Listings */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl font-heading font-bold mb-2">Featured Listings</h2>
              <p className="text-muted-foreground">Hand-picked properties and items just for you.</p>
            </div>
            <Link href="/listings">
              <Button variant="ghost" className="hidden md:flex">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredListings.map(listing => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>

          <div className="mt-12 text-center md:hidden">
            <Link href="/listings">
              <Button variant="outline" className="w-full">
                View All Listings
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 bg-primary text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div className="flex flex-col items-center">
              <div className="bg-white/10 p-4 rounded-full mb-6 backdrop-blur-sm">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Verified Listings</h3>
              <p className="text-white/80">Every property and item listed on Unik is verified for authenticity and quality.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/10 p-4 rounded-full mb-6 backdrop-blur-sm">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Direct Communication</h3>
              <p className="text-white/80">Connect directly with the seller. No hidden fees or middlemen involved.</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="bg-white/10 p-4 rounded-full mb-6 backdrop-blur-sm">
                <HomeIcon className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">Premium Service</h3>
              <p className="text-white/80">Experience top-tier customer support and a seamless buying journey.</p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}