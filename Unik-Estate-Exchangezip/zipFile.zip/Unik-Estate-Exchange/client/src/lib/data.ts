export interface Listing {
  id: string;
  title: string;
  category: "Real Estate" | "Hostel" | "Student Item" | "Land" | "Shop";
  price: string;
  location: string;
  image: string;
  description: string;
  condition?: "New" | "Used" | "Like New";
  features?: string[];
  isFeatured?: boolean;
}

// Re-using the stock images we downloaded for mock data consistency
import realEstateImg from "@assets/stock_images/modern_luxury_apartm_419233ff.jpg"
import hostelImg from "@assets/stock_images/modern_student_hoste_20618d52.jpg"
import studentItemsImg from "@assets/stock_images/student_essentials_l_e2ec2f99.jpg"

export const listings: Listing[] = [
  {
    id: "1",
    title: "Luxury 3BHK Apartment",
    category: "Real Estate",
    price: "$1,200/mo",
    location: "Downtown District, City Center",
    image: realEstateImg,
    description: "Modern apartment with city views, swimming pool access, and 24/7 security. Perfect for professionals.",
    features: ["3 Bedrooms", "2 Bathrooms", "Swimming Pool", "Gym", "Parking"],
    isFeatured: true
  },
  {
    id: "2",
    title: "MacBook Pro M1 (2020)",
    category: "Student Item",
    price: "$850",
    location: "University Campus, Engineering Block",
    image: studentItemsImg,
    description: "Slightly used MacBook Pro, perfect condition. Battery health 95%. Includes original charger and box.",
    condition: "Like New",
    isFeatured: true
  },
  {
    id: "3",
    title: "Sunshine Student Hostel",
    category: "Hostel",
    price: "$300/sem",
    location: "5 min walk from Main Gate",
    image: hostelImg,
    description: "Affordable shared rooms with high-speed WiFi, study halls, and mess facilities included.",
    features: ["WiFi", "Mess", "Laundry", "Study Hall"],
    isFeatured: true
  },
  {
    id: "4",
    title: "Commercial Shop Space",
    category: "Shop",
    price: "$25,000",
    location: "Market Square",
    image: realEstateImg, // Using same for mockup
    description: "Prime location for retail business. High footfall area with glass frontage.",
    isFeatured: false
  },
  {
    id: "5",
    title: "Engineering Textbooks Bundle",
    category: "Student Item",
    price: "$50",
    location: "Library Cafe",
    image: studentItemsImg, // Using same for mockup
    description: "Complete set of 1st year Engineering books. Calculus, Physics, and Mechanics.",
    condition: "Used",
    isFeatured: false
  },
  {
    id: "6",
    title: "5 Acre Farm Land",
    category: "Land",
    price: "$150,000",
    location: "North Countryside",
    image: realEstateImg, // Using same for mockup
    description: "Fertile land suitable for farming or farmhouse construction. Water connection available.",
    isFeatured: true
  }
];